
package onlinebankaccountsystem;
import java.util.Scanner;
import java.util.InputMismatchException;
class InvalidAmountException extends Exception {
    public InvalidAmountException(String message) {
        super(message);
    }
}

class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

class BankAccount {
    private String accountHolder;
    private double balance;

    public BankAccount(String accountHolder) {
        this.accountHolder = accountHolder;
        this.balance = 0.0;
    }

    public void deposit(double amount) throws InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Deposit amount must be positive.");
        }
        this.balance += amount;
        System.out.println("Deposited: Rs" + amount);
    }

    public void withdraw(double amount) throws InsufficientFundsException, InvalidAmountException {
        if (amount <= 0) {
            throw new InvalidAmountException("Withdrawal amount must be positive.");
        }
        if (amount > this.balance) {
            throw new InsufficientFundsException("Insufficient funds. Current balance: Rs" + this.balance);
        }
        this.balance -= amount;
        System.out.println("Withdrew: Rs" + amount);
    }

    public void displayBalance() {
        System.out.println("Current balance: Rs" + this.balance);
    }
}
public class onlinebank {
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankAccount account = null;

        try {
            System.out.println("Welcome to the Bank Account Management System!");
            while (true) {
                System.out.println("\n1. Create Account");
                System.out.println("2. Deposit Money");
                System.out.println("3. Withdraw Money");
                System.out.println("4. View Balance");
                System.out.println("5. Exit");
                System.out.print("Please choose an option: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1: 
                    	System.out.print("Enter account holder's name: ");
                        scanner.nextLine(); // Consume leftover newline character
                        String name = scanner.nextLine();  
                        account = new BankAccount(name);
                        System.out.println("Account created for " + name);
                        break;

                    case 2:  
                        if (account == null) {
                            System.out.println("Please create an account first.");
                            break;
                        }
                        System.out.print("Enter deposit amount: ");
                        double depositAmount = scanner.nextDouble();
                        try {
                            account.deposit(depositAmount);
                        } catch (InvalidAmountException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                        break;

                    case 3:  
                        if (account == null) {
                            System.out.println("Please create an account first.");
                            break;
                        }
                        System.out.print("Enter withdrawal amount: ");
                        double withdrawalAmount = scanner.nextDouble();
                        try {
                            account.withdraw(withdrawalAmount);
                        } catch (InvalidAmountException | InsufficientFundsException e) {
                            System.out.println("Error: " + e.getMessage());
                        }
                        break;

                    case 4:  
                        if (account == null) {
                            System.out.println("Please create an account first.");
                            break;
                        }
                        account.displayBalance();
                        break;

                    case 5:  
                        System.out.println("Exiting the system. Goodbye!");
                        return;

                    default:
                        System.out.println("Invalid choice. Please select a valid option.");
                }
            }

        } catch (InputMismatchException e) {
            System.out.println("Error: Invalid input. Please enter a number.");
            scanner.nextLine(); 
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        } finally {
            System.out.println("Closing resources...");
            scanner.close();
        }
    }
}
