/*
 * Program: Power Calculator with Exception Handling
 * 
 * How I Solved the Program:
 * - Created a class called MyCalculator with a method power(int n, int p).
 * - Inside the power() method:
 *     - Checked if n or p is negative → throw an Exception with message "n or p should not be negative."
 *     - Checked if both n and p are zero → throw an Exception with message "n and p should not be zero."
 *     - Otherwise, calculated n^p using Math.pow() and returned the result.
 * - In the main method:
 *     - Used Scanner and hasNext() to keep reading multiple inputs (n and p).
 *     - Called the power() method inside a try-catch block.
 *     - Printed the result if no exception occurs.
 *     - Printed the exception message if any exception is thrown.
 * - Closed the Scanner at the end.
 * 
 * Author: [Your Name]
 */

package onlinebankaccountsystem;

import java.util.Scanner;

class MyCalculator {
    public int power(int n, int p) throws Exception {
        if (n < 0 || p < 0) {
            throw new Exception("n or p should not be negative.");
        }
        if (n == 0 && p == 0) {
            throw new Exception("n and p should not be zero.");
        }
        return (int) Math.pow(n, p);
    }
}

public class Q2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        MyCalculator calculator = new MyCalculator();

        while (scanner.hasNext()) {
            try {
                int n = scanner.nextInt();
                int p = scanner.nextInt();
                int result = calculator.power(n, p);
                System.out.println(result);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
        
        scanner.close();
    }
}

