/*
 * Program: Employee Details Validation
 * 
 * How I Solved the Program:
 * - Created three custom exception classes:
 *     1. InvalidNameException
 *     2. InvalidEmployeeIDException
 *     3. InvalidDepartmentIDException
 * - Wrote separate validation methods for name, employee ID, and department ID.
 * - Used Scanner to take input from the user at runtime.
 * - Applied validation methods immediately after taking input.
 * - If input is invalid, threw the appropriate custom exception.
 * - Used try-catch-finally block to handle exceptions and ensure Scanner is closed.
 * - Printed employee details if all inputs are valid.
 */
package onlinebankaccountsystem;

import java.util.Scanner;
class InvalidNameException extends Exception {
    public InvalidNameException(String message) {
        super(message);
    }
}

class InvalidEmployeeIDException extends Exception {
    public InvalidEmployeeIDException(String message) {
        super(message);
    }
}

class InvalidDepartmentIDException extends Exception {
    public InvalidDepartmentIDException(String message) {
        super(message);
    }
}

public class Q1 {
	 public static void validateEmployeeName(String name) throws InvalidNameException {
	        if (name == null || name.isEmpty() || !Character.isUpperCase(name.charAt(0))) {
	            throw new InvalidNameException("Error: Employee name should start with a capital letter.");
	        }
	    }

	    public static void validateEmployeeID(int employeeID) throws InvalidEmployeeIDException {
	        if (employeeID < 2001 || employeeID > 5001) {
	            throw new InvalidEmployeeIDException("Error: Employee ID must be between 2001 and 5001.");
	        }
	    }

	    public static void validateDepartmentID(int departmentID) throws InvalidDepartmentIDException {
	        if (departmentID < 1 || departmentID > 5) {
	            throw new InvalidDepartmentIDException("Error: Department ID must be between 1 and 5.");
	        }
	    }

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        try {
	            System.out.print("Enter Employee ID: ");
	            int employeeID = scanner.nextInt();
	            validateEmployeeID(employeeID);

	            
	            System.out.print("Enter Employee Name: ");
	            scanner.nextLine(); 
	            String employeeName = scanner.nextLine();
	            validateEmployeeName(employeeName);

	            System.out.print("Enter Department ID: ");
	            int departmentID = scanner.nextInt();
	            validateDepartmentID(departmentID);

	            System.out.println("\nEmployee Details:");
	            System.out.println("Employee ID: " + employeeID);
	            System.out.println("Employee Name: " + employeeName);
	            System.out.println("Department ID: " + departmentID);

	        } catch (InvalidNameException | InvalidEmployeeIDException | InvalidDepartmentIDException e) {
	            System.out.println(e.getMessage());
	        } finally {
	            
	            scanner.close();
	        }
	    }
}



